import pygame
import os
import random

# Global Constants
SCREEN_HEIGHT = 600 # 스크린 세로 길이
SCREEN_WIDTH = 1100 # 스크린 가로 길이
SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT)) # 스크린 가로 세로 길이 정하기.
file_path ="C:/Users/stat_/Desktop/개발 프로젝트/rupi_game/"
rupi_path = "C:/Users/stat_/Desktop/개발 프로젝트/rupi_game/이미지/"
RUNNING = [pygame.image.load(os.path.join(rupi_path+"루피", "걷는_루피_1.png")),
    pygame.image.load(os.path.join(rupi_path+"루피", "걷는_루피_2.png"))] # 용이 뛰는 사진
JUMPING = pygame.image.load(os.path.join(rupi_path+"루피",  "점프하는_루피.png"))
DUCKING = [pygame.image.load(os.path.join(rupi_path+"루피", "슬라이드_루피.png")),
           pygame.image.load(os.path.join(rupi_path+"루피", "슬라이드_루피1.png"))] # 용이 엎드린 사진

SMALL_CACTUS = [pygame.image.load(os.path.join(rupi_path+"장애물", "SmallPaper1.png")),
            pygame.image.load(os.path.join(rupi_path+"장애물", "SmallPaper2.png")),
            pygame.image.load(os.path.join(rupi_path+"장애물", "SmallPaper3.png"))] # 작은 선인장
LARGE_CACTUS = [pygame.image.load(os.path.join(rupi_path+"장애물", "LargePaper1.png")),
            pygame.image.load(os.path.join(rupi_path+"장애물", "LargePaper2.png")),
            pygame.image.load(os.path.join(rupi_path+"장애물", "LargePaper3.png"))] # 큰 선인장

BIRD = [pygame.image.load(os.path.join(rupi_path+"장애물", "Paper_bird1.png")),
    pygame.image.load(os.path.join(rupi_path+"장애물", "Paper_bird2.png"))]

CLOUD = pygame.image.load(os.path.join(file_path+"Assets/Other", "Cloud.png"))

BD = [pygame.image.load(os.path.join(rupi_path+"배경/낮", "건물1.png")),
            pygame.image.load(os.path.join(rupi_path+"배경/낮", "건물2.png")),
            pygame.image.load(os.path.join(rupi_path+"배경/낮", "건물3.png"))]

BG = pygame.image.load(os.path.join(file_path+"Assets/Other", "Track.png"))

ITEMS = [pygame.image.load(os.path.join(file_path+"Assets/Dino", "scissors1.png")),
    pygame.image.load(os.path.join(file_path+"Assets/Dino", "scissors2.png")),
    pygame.image.load(os.path.join(file_path+"Assets/Dino", "scissors3.png"))]

HEARTS = [pygame.image.load(os.path.join(file_path+"Assets/Dino", "hearts1.png")),
    pygame.image.load(os.path.join(file_path+"Assets/Dino", "hearts2.png")),
    pygame.image.load(os.path.join(file_path+"Assets/Dino", "hearts3.png"))]

RUPIMAIN = [pygame.image.load(os.path.join(file_path+"Assets/Dino", "Rupi_main.png"))]

pygame.init()

# Global Constants

class Dinosaur: # 다이노소어 CLASS
    # 글로벌 변수 지정 #
    X_POS = 80  # 다이노 가로 크기지정 80
    Y_POS = 310 # 다이노 세로 크기지정 310
    Y_POS_DUCK = 340
    JUMP_VEL = 8.5 

    def __init__(self): # 다이노소어 CLASS 내 함수들의 기본정보를 불러옴.(인수에 self가 들어가면 매번 아래값으로 초기화됨.)
        # 즉 다이노가 처음 뛰기전 자리로 초기화 됨 #
        self.duck_img = DUCKING # duck_img 객체에 DUCKING 이미지들 저장
        self.run_img = RUNNING  # run_img 객체에 RUNNING 이미지들 저장
        self.jump_img = JUMPING # JUMP_img 객체에 JUMPING 이미지들 저장

        self.dino_duck = False # dino_duck 객체의 기본값은 False
        self.dino_run = True # dino_run 객체의 기본값은 True
        self.dino_jump = False # dino_jump 객체의 기본값은 False

        self.step_index = 0 # 장애물과의 거리
        self.jump_vel = self.JUMP_VEL # 점프 높이 지정
        self.image = self.run_img[0]
        self.dino_rect = self.image.get_rect() #실제 반응하는 그림은 사각형
        self.dino_rect.x = self.X_POS #사각형 가로크기 초기화 
        self.dino_rect.y = self.Y_POS #사긱형 세로크기 초기화

    def update(self, userInput):# 키 입력에 따라 다이노소어 위치 변경
        if self.dino_duck:
            self.duck() # duck 함수 실행
        if self.dino_run:
            self.run() # Run 함수 실행
        if self.dino_jump:
            self.jump() # jump 함수 실행

        if self.step_index >= 10 : # 10: #장애물과의 거리가 10보다 더 커지면 장애물에 걸림
            self.step_index = 0 # ???

        if userInput[pygame.K_UP] and not self.dino_jump: # 키보드 업키를 누르며 다이노가 점프중이 아니라면
            self.dino_duck = False # 엎드리기 불가
            self.dino_run = False # 달리기 불가
            self.dino_jump = True # 점프 가능
        elif userInput[pygame.K_DOWN] and not self.dino_jump: #키보드 다운키를 누르며 다이노가 점프중이아니라면
            self.dino_duck = True # 엎드리기 가능
            self.dino_run = False # 달리기 불가능
            self.dino_jump = False # 점프 불가능
        elif not (self.dino_jump or userInput[pygame.K_DOWN]): # 다이노가 점프하거나 키보드 다운키 둘중 하나가 아니라면
            self.dino_duck = False # 엎드리기 불가능
            self.dino_run = True # 달리기 가능
            self.dino_jump = False # 점프 불가능

    def duck(self):# 엎드리기 함수
        self.image = self.duck_img[self.step_index // 5] # 엎드릴 경우 장애물과의 거리가 5로 나누어짐
        self.dino_rect = self.image.get_rect() #__init__ 함수내 다이노 초기 형태가져오기
        self.dino_rect.x = self.X_POS #__init__ 함수 내 다이노 초기 형태가져오기
        self.dino_rect.y = self.Y_POS_DUCK #__init__ 함수 내 다이노 초기 형태가져오기
        self.step_index += 5 # ?? 아직 이해 못함

    def run(self): # 달리기 함수
        self.image = self.run_img[self.step_index // 5] # 달릴 경우 장애물과의 거리가 5로 나누어짐
        self.dino_rect = self.image.get_rect()
        self.dino_rect.x = self.X_POS
        self.dino_rect.y = self.Y_POS
        self.step_index += 5

    def jump(self): # 점프 함수
        self.image = self.jump_img # 뛸 경우 뛰는 이미지 가져오기
        if self.dino_jump:
            self.dino_rect.y -= self.jump_vel * 4 # 뛸 경우 기존 뛰는 거리의 4배만큼  # 4
            self.jump_vel -= 0.8
        if self.jump_vel < - self.JUMP_VEL:
            self.dino_jump = False
            self.jump_vel = self.JUMP_VEL

    def draw(self, SCREEN): # 다이노 위치 시시각각 그리기
        SCREEN.blit(self.image, (self.dino_rect.x, self.dino_rect.y))


class Cloud: # 구름이미지
    def __init__(self):
        self.x = SCREEN_WIDTH + random.randint(800, 1000) # 800에서 1000사이의 거리가 랜덤으로 선택됨
        self.y = random.randint(50, 100) # y는 50에서 100사이의 거리가 랜덤으로 선택됨
        self.image = CLOUD # 구름 이미지 같이 하기
        self.width = self.image.get_width() # 가로 같이 하기

    def update(self):
        self.x -= game_speed 
        if self.x < -self.width:
            self.x = SCREEN_WIDTH + random.randint(2500, 3000)
            self.y = random.randint(50, 100)

    def draw(self, SCREEN):
        SCREEN.blit(self.image, (self.x, self.y))


class Building_img1: # 건물이미지
    def __init__(self):
        self.x = SCREEN_WIDTH + random.randint(300, 500) # 800에서 1000사이의 거리가 랜덤으로 선택됨
        self.y = -470 #random.randint(50, 100) # y는 50에서 100사이의 거리가 랜덤으로 선택됨
        self.image = BD[0]
        self.width = self.image.get_width() 

    def update(self):
        self.x -= game_speed 
        if self.x < -self.width:
            self.x = SCREEN_WIDTH + random.randint(300, 500)
            self.y = -470#random.randint(50, 100)

    def draw(self, SCREEN):
        SCREEN.blit(self.image, (self.x, self.y))

class Building_img2: # 건물이미지
    def __init__(self):
        self.x = SCREEN_WIDTH + random.randint(2000, 3000) # 800에서 1000사이의 거리가 랜덤으로 선택됨
        self.y = -470 #random.randint(50, 100) # y는 50에서 100사이의 거리가 랜덤으로 선택됨
        self.image = BD[1] 
        self.width = self.image.get_width() # 가로 같이 하기

    def update(self):
        self.x -= game_speed 
        if self.x < -self.width:
            self.x = SCREEN_WIDTH + random.randint(2000, 3000)
            self.y = -470#random.randint(50, 100)

    def draw(self, SCREEN):
        SCREEN.blit(self.image, (self.x, self.y))

class Building_img3: # 건물이미지
    def __init__(self):
        self.x = SCREEN_WIDTH + random.randint(5000, 8000) # 800에서 1000사이의 거리가 랜덤으로 선택됨
        self.y = -470 #random.randint(50, 100) # y는 50에서 100사이의 거리가 랜덤으로 선택됨
        self.image = BD[2]
        self.width = self.image.get_width() # 가로 같이 하기

    def update(self):
        self.x -= game_speed 
        if self.x < -self.width:
            self.x = SCREEN_WIDTH + random.randint(5000, 8000)
            self.y = -470#random.randint(50, 100)

    def draw(self, SCREEN):
        SCREEN.blit(self.image, (self.x, self.y))


class Obstacle:
    def __init__(self, image, type):
        self.image = image
        self.type = type
        self.rect = self.image[self.type].get_rect()
        self.rect.x = SCREEN_WIDTH

    def update(self):
        self.rect.x -= game_speed
        if self.rect.x < -self.rect.width:
            obstacles.pop()

    def draw(self, SCREEN):
        SCREEN.blit(self.image[self.type], self.rect)


class SmallCactus(Obstacle):
    def __init__(self, image):
        self.type = random.randint(0, 2)
        super().__init__(image, self.type)
        self.rect.y = 325


class LargeCactus(Obstacle):
    def __init__(self, image):
        self.type = random.randint(0, 2)
        super().__init__(image, self.type)
        self.rect.y = 300


class Bird(Obstacle):
    def __init__(self, image):
        self.type = 0
        super().__init__(image, self.type)
        self.rect.y = 250
        self.index = 0

    def draw(self, SCREEN):
        if self.index >= 9:
            self.index = 0
        SCREEN.blit(self.image[self.index//5], self.rect)
        self.index += 1


def main():
    global game_speed, x_pos_bg, y_pos_bg, points, obstacles
    run = True
    clock = pygame.time.Clock()
    player = Dinosaur()
    cloud = Cloud()
    Building1 = Building_img1()
    Building2 = Building_img2()
    Building3 = Building_img3()
    game_speed = 20
    x_pos_bg = 0
    y_pos_bg = 380
    points = 0
    font = pygame.font.Font('freesansbold.ttf', 20)
    obstacles = []
    death_count = 0


    def score():
        global points, game_speed
        points += 1
        if points % 100 == 0:
            game_speed += 1

        text = font.render("Points: " + str(points), True, (0, 0, 0))
        textRect = text.get_rect()
        textRect.center = (1000, 40)
        SCREEN.blit(text, textRect)
        
    ### 유저 가위 추가 부분 ##
    def items():
        SCREEN.blit(ITEMS[0], (150, 65))
        SCREEN.blit(ITEMS[1], (190, 65))
        SCREEN.blit(ITEMS[2], (230, 65))

    ### 하트 추가 부분 ##
    def hearts():
        SCREEN.blit(HEARTS[0], (150, 35))
        SCREEN.blit(HEARTS[1], (190, 35))
        SCREEN.blit(HEARTS[2], (230, 35))

    ### 루피 프로필 부분 ##
    def rupi_main():
        SCREEN.blit(RUPIMAIN[0], (00, 00))

    
    def background():
        global x_pos_bg, y_pos_bg
        image_width = BG.get_width()
        SCREEN.blit(BG, (x_pos_bg, y_pos_bg))
        SCREEN.blit(BG, (image_width + x_pos_bg, y_pos_bg))
        if x_pos_bg <= -image_width:
            SCREEN.blit(BG, (image_width + x_pos_bg, y_pos_bg))
            x_pos_bg = 0
        x_pos_bg -= game_speed


         
        
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        SCREEN.fill((255, 255, 255))
        userInput = pygame.key.get_pressed()

        background()

        cloud.draw(SCREEN)
        cloud.update()

        Building1.draw(SCREEN)
        Building1.update()
        
        Building2.draw(SCREEN)
        Building2.update()

        Building3.draw(SCREEN)
        Building3.update()

        player.draw(SCREEN)
        player.update(userInput)

        if len(obstacles) == 0: # 장애물 랜덤으로 등장
            if random.randint(0, 2) == 0:
                obstacles.append(SmallCactus(SMALL_CACTUS))
            elif random.randint(0, 2) == 1:
                obstacles.append(LargeCactus(LARGE_CACTUS))
            elif random.randint(0, 2) == 2:
                obstacles.append(Bird(BIRD))

        for obstacle in obstacles: # 충돌 발생
            obstacle.draw(SCREEN)
            obstacle.update()
            if points < 300 :
                if player.dino_rect.colliderect(obstacle.rect):
                    pygame.time.delay(2000)
                    death_count += 1
                    menu(death_count)
            elif points >= 300 :
                continue

                



        score()
        items()
        hearts()
        rupi_main()
        
        clock.tick(30)
        pygame.display.update()

 
############################################
def menu(death_count):
    global points
    run = True
    while run:
        SCREEN.fill((255, 255, 255))
        font = pygame.font.Font('freesansbold.ttf', 30)

        if death_count == 0:
            text = font.render("Press any Key to Start", True, (0, 0, 0))
        elif death_count > 0:
            text = font.render("Press any Key to Restart", True, (0, 0, 0))
            score = font.render("Your Score: " + str(points), True, (0, 0, 0))
            scoreRect = score.get_rect()
            scoreRect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50)
            SCREEN.blit(score, scoreRect)
        textRect = text.get_rect()
        textRect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        SCREEN.blit(text, textRect)
        SCREEN.blit(RUNNING[0], (SCREEN_WIDTH // 2 - 20, SCREEN_HEIGHT // 2 - 140))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                sys.exit()
            if event.type == pygame.KEYDOWN:
                main()
############################################
# 캐릭터 이미지 로드
CHAR1 = pygame.image.load(os.path.join(rupi_path+"루피", "게임오버_1.png"))  # 캐릭터1 이미지 파일명에 맞게 수정
CHAR2 = pygame.image.load(os.path.join(rupi_path+"루피", "게임오버_2.png"))  # 캐릭터2 이미지 파일명에 맞게 수정
SELECT_CHAR = [pygame.image.load(os.path.join(file_path+"Assets/Dino", "white.png")),
               pygame.image.load(os.path.join(rupi_path+"루피", "걷는_루피_1.png")),
               pygame.image.load(os.path.join(file_path+"Assets/Dino", "white.png")),
               pygame.image.load(os.path.join(rupi_path+"루피", "걷는_루피_2.png"))]
clock = pygame.time.Clock()
def character_selection():
    global points, CHAR1
    run = True
    while run:
        SCREEN.fill((255, 255, 255))
        font = pygame.font.SysFont('malgungothic', 15)

        # 캐릭터 이미지 출력
        SCREEN.blit(CHAR1, (300, 150))
        # 이미지별 설명 #
        char1_explain = font.render("1번 캐릭설명", True, (0, 0, 0))
        SCREEN.blit(char1_explain, (450,150))
        #################
        SCREEN.blit(CHAR2, (300, 300))
        char1_explain = font.render("2번 캐릭설명", True, (0, 0, 0))
        SCREEN.blit(char1_explain, (450,300))
        #################
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                sys.exit()
            ### 캐릭터선택 코드 ###
            if event.type == pygame.KEYDOWN :
                ### 캐릭터 선택 1 ###
                if event.key == pygame.K_UP:
                    for i in range(0,3) :
                       for j in range(0,4) :
                           CHAR_SELECT = SELECT_CHAR[j]
                           SCREEN.blit(CHAR_SELECT, (300, 150))
                           pygame.time.delay(100)
                           pygame.display.flip()
                    menu(death_count=0)
                ### 캐릭터 선택 2 ###
                elif event.key == pygame.K_DOWN:
                    for i in range(0,3) :
                        for j in range(0,4) :
                           CHAR_SELECT = SELECT_CHAR[j]
                           SCREEN.blit(CHAR_SELECT, (300, 300))
                           pygame.time.delay(100)
                           pygame.display.flip()
                    menu(death_count=0)
############################################


#menu(death_count=0)
character_selection()